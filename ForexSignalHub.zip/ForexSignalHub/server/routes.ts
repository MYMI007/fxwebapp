import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { TelegramBot } from "./telegram";
import { insertSignalSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);
  const telegramBot = TelegramBot.getInstance();

  app.get("/api/signals", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const signals = await storage.getSignals();
    res.json(signals);
  });

  app.post("/api/signals", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const parsed = insertSignalSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }

    const signal = await storage.createSignal(parsed.data);
    
    // Send telegram notification if user has chatId
    if (req.user?.telegramChatId) {
      await telegramBot.sendSignal(req.user.telegramChatId, signal);
    }

    res.status(201).json(signal);
  });

  app.post("/api/telegram/chat", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { chatId } = req.body;
    if (!chatId) return res.status(400).json({ error: "Chat ID required" });

    const user = await storage.updateUserTelegramChat(req.user.id, chatId);
    res.json(user);
  });

  const httpServer = createServer(app);
  return httpServer;
}
