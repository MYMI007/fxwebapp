import { IStorage } from "./storage";
import { User, Signal, InsertUser, InsertSignal } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private signals: Map<number, Signal>;
  public sessionStore: session.Store;
  private currentUserId: number;
  private currentSignalId: number;

  constructor() {
    this.users = new Map();
    this.signals = new Map();
    this.currentUserId = 1;
    this.currentSignalId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, telegramChatId: null };
    this.users.set(id, user);
    return user;
  }

  async createSignal(signal: InsertSignal): Promise<Signal> {
    const id = this.currentSignalId++;
    const newSignal: Signal = {
      ...signal,
      id,
      status: "open",
      createdAt: new Date(),
    };
    this.signals.set(id, newSignal);
    return newSignal;
  }

  async getSignals(): Promise<Signal[]> {
    return Array.from(this.signals.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async updateUserTelegramChat(userId: number, chatId: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, telegramChatId: chatId };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
}

export const storage = new MemStorage();
