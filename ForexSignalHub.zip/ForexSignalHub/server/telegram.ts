import { Signal } from '@shared/schema';

export class TelegramBot {
  private static instance: TelegramBot;
  private token: string;

  private constructor() {
    this.token = process.env.TELEGRAM_BOT_TOKEN || '';
  }

  public static getInstance(): TelegramBot {
    if (!TelegramBot.instance) {
      TelegramBot.instance = new TelegramBot();
    }
    return TelegramBot.instance;
  }

  async sendSignal(chatId: string, signal: Signal): Promise<void> {
    if (!this.token) return;

    const message = `
🚨 NEW FOREX SIGNAL

Pair: ${signal.pair}
Direction: ${signal.direction === 'buy' ? '📈 BUY' : '📉 SELL'}
Entry: ${signal.entryPrice}
Stop Loss: ${signal.stopLoss}
Take Profit: ${signal.takeProfit}

⚡️ Entry price: ${signal.entryPrice}
🛑 Stop Loss: ${signal.stopLoss}
✅ Take Profit: ${signal.takeProfit}
    `;

    try {
      await fetch(`https://api.telegram.org/bot${this.token}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'HTML',
        }),
      });
    } catch (error) {
      console.error('Failed to send Telegram message:', error);
    }
  }
}
