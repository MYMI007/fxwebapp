import { Signal } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export function SignalList({ signals }: { signals: Signal[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Date</TableHead>
          <TableHead>Pair</TableHead>
          <TableHead>Direction</TableHead>
          <TableHead>Entry</TableHead>
          <TableHead>Stop Loss</TableHead>
          <TableHead>Take Profit</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {signals.map((signal) => (
          <TableRow key={signal.id}>
            <TableCell>
              {format(new Date(signal.createdAt), "MMM d, HH:mm")}
            </TableCell>
            <TableCell>{signal.pair}</TableCell>
            <TableCell>
              <Badge
                variant={signal.direction === "buy" ? "default" : "destructive"}
              >
                {signal.direction.toUpperCase()}
              </Badge>
            </TableCell>
            <TableCell>{signal.entryPrice}</TableCell>
            <TableCell>{signal.stopLoss}</TableCell>
            <TableCell>{signal.takeProfit}</TableCell>
            <TableCell>
              <Badge variant={signal.status === "open" ? "secondary" : "outline"}>
                {signal.status}
              </Badge>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
