import { useEffect, useRef } from "react";

declare global {
  interface Window {
    TradingView: {
      widget: new (config: any) => any;
    };
  }
}

export function TradingViewWidget() {
  const container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!container.current) return;

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/tv.js";
    script.async = true;
    script.onload = () => {
      if (typeof window.TradingView !== 'undefined') {
        new window.TradingView.widget({
          width: "100%",
          height: 600,
          symbol: "FX:EURUSD",
          interval: "D",
          timezone: "Etc/UTC",
          theme: "dark",
          style: "1",
          locale: "tr",
          toolbar_bg: "#1e293b",
          enable_publishing: false,
          allow_symbol_change: true,
          container_id: "tradingview_chart",
          studies: [
            // Trend Göstergeleri
            "MASimple@tv-basicstudies", // SMA
            "MAExp@tv-basicstudies", // EMA
            "VWAP@tv-basicstudies",
            "PivotPointsStandard@tv-basicstudies",

            // Momentum Göstergeleri
            "RSI@tv-basicstudies",
            "BB@tv-basicstudies", // Bollinger Bands
            "StochasticRSI@tv-basicstudies",
            "ADX@tv-basicstudies",
            "CCI@tv-basicstudies",
            "AroonOsc@tv-basicstudies",
          ],
          drawings: {
            enabled: true,
            tools: {
              FibRetracement: true,
              FibFan: true,
              FibArc: true,
              FibSpiral: true,
              TrendLine: true,
              Rectangle: true,
              Brush: true,
              PriceRange: true,
              Pitchfork: true,
            }
          },
          show_popup_button: true,
          popup_width: "1000",
          popup_height: "650",
          saved_data: {
            charts_storage_url: "https://saveload.tradingview.com",
            client_id: "tradingview.com",
            user_id: "public_user",
          },
          overrides: {
            "mainSeriesProperties.candleStyle.upColor": "#26a69a",
            "mainSeriesProperties.candleStyle.downColor": "#ef5350",
            "mainSeriesProperties.candleStyle.drawWick": true,
            "mainSeriesProperties.candleStyle.drawBorder": true,
            "mainSeriesProperties.candleStyle.borderUpColor": "#26a69a",
            "mainSeriesProperties.candleStyle.borderDownColor": "#ef5350",
          }
        });
      }
    };
    container.current.appendChild(script);

    return () => {
      if (container.current) {
        const scriptElement = container.current.querySelector("script");
        if (scriptElement) {
          container.current.removeChild(scriptElement);
        }
      }
    };
  }, []);

  return (
    <div className="tradingview-widget-container" ref={container}>
      <div id="tradingview_chart" />
    </div>
  );
}