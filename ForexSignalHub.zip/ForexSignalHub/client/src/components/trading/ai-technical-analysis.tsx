import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Brain, TrendingUp, Target } from "lucide-react";

export function AITechnicalAnalysis() {
  const [selectedPair, setSelectedPair] = useState("EURUSD");

  return (
    <Card>
      <CardHeader className="bg-muted/50">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Brain className="h-6 w-6 text-primary" />
          </div>
          <CardTitle>AI Teknik Analiz</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <Tabs defaultValue="patterns" className="space-y-4">
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="patterns">Formasyon Tanıma</TabsTrigger>
            <TabsTrigger value="divergence">RSI Uyuşmazlık</TabsTrigger>
            <TabsTrigger value="orderblocks">Order Blocks</TabsTrigger>
          </TabsList>

          <TabsContent value="patterns" className="space-y-4">
            <div className="p-4 bg-muted/50 rounded-lg">
              <h3 className="font-semibold mb-3">Tespit Edilen Formasyonlar</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Bullish Engulfing</span>
                  <Badge variant="default">Yükseliş Sinyali</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Evening Doji Star</span>
                  <Badge variant="destructive">Düşüş Sinyali</Badge>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="divergence" className="space-y-4">
            <div className="p-4 bg-muted/50 rounded-lg">
              <h3 className="font-semibold mb-3">RSI Uyuşmazlık Analizi</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Bearish Divergence</span>
                  <Badge variant="destructive">RSI: 72.5</Badge>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  Fiyat yükselirken RSI düşüş gösteriyor. Potansiyel trend dönüşü sinyali.
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="orderblocks" className="space-y-4">
            <div className="p-4 bg-muted/50 rounded-lg">
              <h3 className="font-semibold mb-3">FVG ve Order Block Tespiti</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span>Bullish Order Block</span>
                  <Badge>1.0850-1.0870</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Fair Value Gap</span>
                  <Badge variant="secondary">1.0920-1.0935</Badge>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
