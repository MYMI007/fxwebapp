import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Brain } from "lucide-react";

export function AIStrategyOptimizer() {
  const [isOptimizing, setIsOptimizing] = useState(false);

  return (
    <Card>
      <CardHeader className="bg-muted/50">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Brain className="h-6 w-6 text-primary" />
          </div>
          <CardTitle>AI Destekli Strateji Optimizasyonu</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-6 space-y-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Strateji Tipi</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Strateji seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="price-action">Price Action</SelectItem>
                <SelectItem value="momentum">Momentum</SelectItem>
                <SelectItem value="trend-following">Trend Takibi</SelectItem>
                <SelectItem value="breakout">Kırılım</SelectItem>
                <SelectItem value="scalping">Scalping</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Test Periyodu (Gün)</Label>
            <Input
              type="number"
              placeholder="30"
              className="bg-background"
            />
          </div>

          <div className="space-y-2">
            <Label>Zaman Dilimi Analizi</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Zaman dilimi seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="M5">5 Dakika (M5)</SelectItem>
                <SelectItem value="M15">15 Dakika (M15)</SelectItem>
                <SelectItem value="H1">1 Saat (H1)</SelectItem>
                <SelectItem value="H4">4 Saat (H4)</SelectItem>
                <SelectItem value="D1">Günlük (D1)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Risk Toleransı (%)</Label>
            <Input
              type="number"
              placeholder="2"
              className="bg-background"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Optimize Edilecek Parametreler</Label>
            <div className="grid gap-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="rsi" className="accent-primary" />
                <label htmlFor="rsi">RSI Seviyeleri (Aşırı Alım/Satım)</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="ma" className="accent-primary" />
                <label htmlFor="ma">Hareketli Ortalama Periyotları</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="bb" className="accent-primary" />
                <label htmlFor="bb">Bollinger Bantları (Standart Sapma)</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="fib" className="accent-primary" />
                <label htmlFor="fib">Fibonacci Seviyeleri</label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="tp-sl" className="accent-primary" />
                <label htmlFor="tp-sl">Take Profit / Stop Loss Oranları</label>
              </div>
            </div>
          </div>

          <Button 
            className="w-full"
            disabled={isOptimizing}
            onClick={() => setIsOptimizing(true)}
          >
            {isOptimizing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Optimizasyon Çalışıyor...
              </>
            ) : (
              'Stratejiyi Optimize Et'
            )}
          </Button>
        </div>

        {isOptimizing && (
          <div className="rounded-lg bg-muted/50 p-4">
            <p className="text-sm text-muted-foreground">
              AI modelimiz seçilen stratejiyi optimize ediyor...
              <br />
              • Geçmiş verileri analiz ediyor
              <br />
              • En uygun zaman dilimini belirliyor
              <br />
              • Gösterge parametrelerini optimize ediyor
              <br />
              Bu işlem birkaç dakika sürebilir.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}