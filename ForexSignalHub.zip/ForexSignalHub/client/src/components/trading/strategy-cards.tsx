import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CandlestickChart, TrendingUp, Target, LineChart, Brain, Gauge } from "lucide-react";

const strategies = [
  {
    title: "AI Pattern Tanıma",
    description: "Yapay zeka destekli mum formasyonu tanıma ve otomatik sinyal üretme sistemi.",
    icon: Brain,
    details: [
      "Boğa/Ayı Engulfing formasyonları",
      "Doji ve Pin Bar tespiti",
      "Hammer ve Shooting Star analizi",
      "Otomatik sinyal üretimi"
    ]
  },
  {
    title: "Teknik Göstergeler",
    description: "Gelişmiş teknik göstergeler ve indikatörler ile analiz.",
    icon: Gauge,
    details: [
      "RSI ve Stochastic RSI",
      "Bollinger Bands analizi",
      "MACD ve ADX göstergeleri",
      "Fibonacci seviyeleri"
    ]
  },
  {
    title: "Likidite Analizi",
    description: "Stop avları, false breakout noktaları ve büyük oyuncuların hareketlerinin analizi.",
    icon: Target,
    details: [
      "Stop hunt bölgeleri",
      "False breakout analizi",
      "Kurumsal likidite alanları",
      "Order flow analizi"
    ]
  },
  {
    title: "AI Trend Analizi",
    description: "Yapay zeka destekli trend analizi ve momentum göstergeleri.",
    icon: TrendingUp,
    details: [
      "Trend gücü analizi",
      "Momentum indikatörleri",
      "Volatilite ölçümü",
      "Hacim profili analizi"
    ]
  }
];

export function StrategyCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {strategies.map((strategy) => (
        <Card key={strategy.title} className="hover:shadow-lg transition-shadow">
          <CardHeader className="bg-muted/50">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <strategy.icon className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>{strategy.title}</CardTitle>
            </div>
            <CardDescription className="mt-2">{strategy.description}</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <ul className="space-y-3">
              {strategy.details.map((detail) => (
                <li key={detail} className="flex items-center gap-3">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  <span className="text-sm text-muted-foreground">{detail}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}