import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function RiskCalculator() {
  const [accountSize, setAccountSize] = useState("");
  const [riskPercentage, setRiskPercentage] = useState("");
  const [entryPrice, setEntryPrice] = useState("");
  const [stopLoss, setStopLoss] = useState("");
  const [takeProfit, setTakeProfit] = useState("");

  const calculatePositionSize = () => {
    const account = parseFloat(accountSize);
    const risk = parseFloat(riskPercentage);
    const entry = parseFloat(entryPrice);
    const stop = parseFloat(stopLoss);

    if (!account || !risk || !entry || !stop) return null;

    const riskAmount = (account * (risk / 100));
    const priceDiff = Math.abs(entry - stop);
    const positionSize = riskAmount / priceDiff;
    const riskRewardRatio = takeProfit ? 
      Math.abs(parseFloat(takeProfit) - entry) / priceDiff : 
      null;

    return {
      positionSize: positionSize.toFixed(2),
      riskAmount: riskAmount.toFixed(2),
      riskRewardRatio: riskRewardRatio?.toFixed(2)
    };
  };

  const result = calculatePositionSize();

  return (
    <Card>
      <CardHeader className="bg-muted/50">
        <CardTitle>Risk Yönetimi Hesaplayıcı</CardTitle>
      </CardHeader>
      <CardContent className="pt-6 space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Hesap Büyüklüğü ($)</Label>
            <Input
              type="number"
              value={accountSize}
              onChange={(e) => setAccountSize(e.target.value)}
              placeholder="10000"
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label>Risk Yüzdesi (%)</Label>
            <Input
              type="number"
              value={riskPercentage}
              onChange={(e) => setRiskPercentage(e.target.value)}
              placeholder="1"
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label>Giriş Fiyatı</Label>
            <Input
              type="number"
              value={entryPrice}
              onChange={(e) => setEntryPrice(e.target.value)}
              placeholder="1.1000"
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label>Stop Loss</Label>
            <Input
              type="number"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              placeholder="1.0950"
              className="bg-background"
            />
          </div>
          <div className="space-y-2">
            <Label>Take Profit</Label>
            <Input
              type="number"
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value)}
              placeholder="1.1100"
              className="bg-background"
            />
          </div>
        </div>

        {result && (
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm font-medium mb-1">Pozisyon Büyüklüğü</p>
              <p className="text-2xl font-bold text-primary">{result.positionSize}</p>
            </div>
            <div className="p-4 bg-muted/50 rounded-lg">
              <p className="text-sm font-medium mb-1">Risk Miktarı ($)</p>
              <p className="text-2xl font-bold text-primary">{result.riskAmount}</p>
            </div>
            {result.riskRewardRatio && (
              <div className="p-4 bg-muted/50 rounded-lg">
                <p className="text-sm font-medium mb-1">Risk/Ödül Oranı</p>
                <p className="text-2xl font-bold text-primary">1:{result.riskRewardRatio}</p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
