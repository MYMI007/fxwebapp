import { Navbar } from "@/components/layout/navbar";
import { TradingViewWidget } from "@/components/trading/chart-widget";
import { SignalList } from "@/components/signals/signal-list";
import { StrategyCards } from "@/components/trading/strategy-cards";
import { useQuery } from "@tanstack/react-query";
import { Signal } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RiskCalculator } from "@/components/trading/risk-calculator";
import { AIStrategyOptimizer } from "@/components/trading/ai-strategy-optimizer";
import { AITechnicalAnalysis } from "@/components/trading/ai-technical-analysis";

export default function HomePage() {
  const { toast } = useToast();
  const [telegramChatId, setTelegramChatId] = useState("");

  const { data: signals = [] } = useQuery<Signal[]>({
    queryKey: ["/api/signals"],
  });

  const handleTelegramSetup = async () => {
    try {
      await apiRequest("POST", "/api/telegram/chat", { chatId: telegramChatId });
      toast({
        title: "Başarılı",
        description: "Telegram bildirimleri başarıyla ayarlandı!",
      });
    } catch (error) {
      toast({
        title: "Hata",
        description: "Telegram bildirimleri ayarlanırken bir hata oluştu",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-6 space-y-8">
        <Tabs defaultValue="chart" className="space-y-8">
          <TabsList className="w-full max-w-md mx-auto grid grid-cols-2">
            <TabsTrigger value="chart">Grafik & Sinyaller</TabsTrigger>
            <TabsTrigger value="strategies">Stratejiler & Analizler</TabsTrigger>
          </TabsList>

          <TabsContent value="chart" className="space-y-8">
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="overflow-hidden lg:col-span-2">
                <CardHeader className="bg-muted/50">
                  <CardTitle>Teknik Analiz Grafiği</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <TradingViewWidget />
                </CardContent>
              </Card>

              <AITechnicalAnalysis />

              <Card>
                <CardHeader className="bg-muted/50">
                  <CardTitle>Telegram Bildirimleri</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="chatId">Telegram Chat ID</Label>
                    <Input
                      id="chatId"
                      value={telegramChatId}
                      onChange={(e) => setTelegramChatId(e.target.value)}
                      placeholder="Telegram chat ID'nizi girin"
                      className="bg-background"
                    />
                  </div>
                  <Button onClick={handleTelegramSetup} className="w-full">
                    Bildirimleri Ayarla
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader className="bg-muted/50">
                <CardTitle>Son Sinyaller</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <SignalList signals={signals} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="strategies" className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              <RiskCalculator />
              <AIStrategyOptimizer />
            </div>

            <Card>
              <CardHeader className="bg-muted/50">
                <CardTitle>Trading Stratejileri</CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <StrategyCards />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}